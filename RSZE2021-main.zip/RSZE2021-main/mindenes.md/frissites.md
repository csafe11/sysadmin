# Az ubuntu frissitése:
```bash
apt update
apt upgrade
apt dist-upgrade
```
