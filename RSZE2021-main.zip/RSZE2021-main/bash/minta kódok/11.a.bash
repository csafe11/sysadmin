#!/bin/bash
# Szémok bekérése addig ammig 0 nem kapun

SZAM=1

while [ $SZAM -ne 0 ]
do
	echo -n "Szám: "
	read SZAM
	## hibáz okoz ha nem szám amit megadunk.. A hibát itt javasolt kezelni.
done
