#!/bin/bash
# szelekció a vizsgálathoz használható a '-eq' '=' '=='
szam=42
if [ $szam -eq $1 ]
then
# igaz ág
echo egyenlő
else
# hamis ág
echo "nem egyenlő"
fi
