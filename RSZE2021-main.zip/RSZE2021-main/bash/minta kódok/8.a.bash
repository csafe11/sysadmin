#!/bin/bash
# töbszörös ferltétel

select i in "egy" "kettő" "három" "kilépés"
do
    echo Ezt választottad:
    echo $i
    if [[ "$i" = "kilépés" ]] ; then
	break
    fi
done
