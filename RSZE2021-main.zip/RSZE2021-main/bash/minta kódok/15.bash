#!/bin/bash
# function példa

kiir () {
    echo "Hello"
}
# mindig meg kell hívni!!
kiir
