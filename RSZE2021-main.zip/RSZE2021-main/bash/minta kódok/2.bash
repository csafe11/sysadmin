#!/bin/bash 
# Környezeti változok használat.
# A $USER környezeti változó a bejelentkezet felhasználó user nevét tartalmazza.
echo "Hello $USER"
