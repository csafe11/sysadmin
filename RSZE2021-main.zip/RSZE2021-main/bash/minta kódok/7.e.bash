#!/bin/bash
# Két feltétel egyidejü vizsgálata.
szam=42
if [ [ feltétel1 ] && [feltétel2]  ]
then
	# igazág
fi
