#!/bin/bash
# dobokocka
echo $(((RANDOM %6)+1))
