#!/bin/bash
# nem egyelőség vizsgálat "-ne", "!="
szam=42
if [ $szam != $1 ]
then
	# igaz ág
	echo "Nem egyenlő $szam"
else
	# hamis ág
	echo "egyenlő $szam"
fi
