#!/bin/bash
A=1
B=1
[ $A -eq 1 ] && [ $B -eq 1 ] && echo "Ok" || echo "Nem ok"
