#!/bin/bash
# function példa
# $1 a functio első paramétere.

kiir () {
    echo "Hello $1"
}
# mindig meg kell hívni!!
kiir test
