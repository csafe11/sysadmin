#!/bin/bash

for (( n=0; n<10; n++ ))
do
	echo "Helló"
done
