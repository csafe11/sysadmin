#!/bin/bash
# Számok bekérése nulla végjelig, közben összegzés.

SZAM=1
SZUM=0

while [ $SZAM -ne 0 ]
do
	echo -n "Szám: "
	read SZAM
	let SZUM=$SZUM+$SZAM
done

echo "Összeg: " $SZUM
