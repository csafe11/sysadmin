#!/bin/bash
A=1
[ $A -eq $1 ] && echo "OK" || echo "Nem ok"
