#!/bin/bash
# tömbök hasznlat
# tömbök hasznlataa
tomb=( "egy" "kettő" "három")
#Másik módszer:
#tomb[0]=egy
#tomb[1]=kettő
#tomb[2]=három
echo ${tomb[1]}

#${tomb[*]}    # a tömb összes eleme
#${!tomb[*]}   # a tömb összes indexe
#${#tomb[*]}   # a tömb elemeinek száma
#${#tomb[0]}   # a 0-dik elem hossza


echo A tömb elemeinek száma: ${#tomb[*]}
