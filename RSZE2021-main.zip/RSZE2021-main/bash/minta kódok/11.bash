#!/bin/bash
SZAMLALO=1

while [ $SZAMLALO -lt 11 ]
do
        echo $SZAMLALO
        let SZAMLALO=SZAMLALO+1
done
