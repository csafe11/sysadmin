#!/bin/bash
while :
do
   #amit csinálunk a végtelen ciklusban
   ping -c 1 8.8.8.8 
   sleep 3
done
