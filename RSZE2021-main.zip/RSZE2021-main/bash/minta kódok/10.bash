#!/bin/bash
# for ciklus 1-10
for i in `seq 1 10`
do
    echo $i
done
