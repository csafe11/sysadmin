#!/bin/bash
# case 

echo "[O]lvas"
echo "[H]ozzáfűz"
echo "[S]zerkeszt"

read menupont

case "$menupont" in
  O)
      echo "Olvasási műveletek"
      ;;
  H)
      echo "Hozzáfűzési műveletek"
      ;;
  S)
      echo "Szerkesztési műveletek"
      ;;
esac
