#!/bin/bash
# A megadott szám Nagyobb vagy egyenlő
szam=42
if [ $szam -le $1 ]
then
	# igaz ág
	echo "Nagyobb vagy egyenlő  $szam"
else
	# hamis ág
	echo "Kisebb mint $szam"
fi
