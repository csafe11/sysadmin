#!/bin/bash
# A megadott szám nagyobb ..
szam=42
if [ $szam -lt $1 ]
then
	# igaz ág
	echo "Nagyobb mint  $szam"
else
	# hamis ág
	echo "Kisebb vagy egyenlő mint a $szam"
fi
