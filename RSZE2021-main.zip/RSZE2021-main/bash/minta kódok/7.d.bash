#!/bin/bash
# A megadott szám Nagyobb vagy egyenlő
szam=42
if [ $szam -ge $1 ]
then
	# igaz ág
	echo "Kisebb vagy egyenlő  $szam"
else
	# hamis ág
	echo "Nagyobb mint $szam"
fi
