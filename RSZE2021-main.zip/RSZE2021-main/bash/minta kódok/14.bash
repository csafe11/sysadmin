#!/bin/bash
s="AlmA"
echo $s
echo ${s^^} # nagy betu

#Alternativ megoldások:
echo "ÁRVÍZTŰRŐ" | awk '{print tolower($0)}'
echo "Árvíztűrő" | awk '{print toupper($0)}'
# csak meghatározott karaktereket alakit át.
STR=árvíztűrő; echo ${STR^^[v,z]}
