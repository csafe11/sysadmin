#!/bin/bash
for i in 1 3 2 5 12 26 11 23 20 10
do
    echo $i
done
