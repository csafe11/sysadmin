#!/bin/bash
# function példa
# $1 a functio első paramétere.
# Visszatérési érték.

kiir () {
    echo "Hello $1"
    return 0
}
# mindig meg kell hívni!!
kiir test
echo A visszatérési érték: $?
