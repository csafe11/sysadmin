#!/bin/bash
# random szám kiiratása
echo "Véletlen szám: "$RANDOM
