#!/bin/bash
# A tömb bejárása

etelek=(
        "Halsaláta"
        "Zöldségkör"
        "Húsleves"
        "Narancs-joghurt"
)

count=${#etelek[@]}

for item in ${etelek[*]}
do
   echo $item
done
