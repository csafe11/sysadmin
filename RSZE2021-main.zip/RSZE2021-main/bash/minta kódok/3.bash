#!/bin/bash
# változok értékadása és használata.
valtozo1="1"
valtozo2="szöveg"
# Nem tipusosak a véltozok!
echo "Ez $valtozo1 teszt $valtozo2"
