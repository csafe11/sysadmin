#!/bin/bash
# Megjegyzés
echo "Hello World"
