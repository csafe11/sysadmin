#!/bin/bash
while :
do
   echo -n "Számot: "
   read SZAM
   if [ $SZAM -lt 1 ]
   then
      exit 0
   fi
done
