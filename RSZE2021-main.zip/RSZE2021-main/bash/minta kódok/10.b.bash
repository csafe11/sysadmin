#!/bin/bash
# for ciklus
for i in `ls /etc`
do
    echo $i
done
