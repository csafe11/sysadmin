#!/bin/bash
szoveg="Test Elek"
meret=${#szoveg}
echo $meret

hoss=$(printf "%s" "$szoveg" | wc -c)
echo $hoss
