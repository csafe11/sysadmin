#!/bin/bash
# változok láthatósága

test123 () {
    local varL="local variable"
    echo "test123:"
    echo "local: "$varL
    echo "global: " $var2
}

var2="alma"
test123
echo "fügvényen kivül:"
echo $varL
echo $var2
