#!/bin/bash
#Végtelen ciklus létrehozása:
while true
do
   #amit csinálunk a végtelen ciklusban
   sleep 3
   echo "Még futok.."
   date
done
