#!/bin/bash
# Beolvasás, elepértelmezett érték megadássával.
read -e -i "alam" -p "Mi a kedven gyümölcsöd? " gyumolcs
echo $gyumolcs
