#!/bin/bash
# töbszörös ferltétel

if [ $1 = "alma" ]
then
	# 1 ág
	echo "alam"
elif [ $1 = "korte" ] 
then
	# 2 ág
	echo "körte"
elif [ $1 = "barack" ]
then
	# ág 3
	echo "Barack"
else
	echo Ez nem alma, körte,barack
fi
