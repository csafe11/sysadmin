#!/bin/bash
# Jelszó beolvasása a felhasználótol.
read -p "jelszo: " -s jelszo
echo "A jelszó: " $jelszo
