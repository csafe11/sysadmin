#!/bin/bash
# Beolvasun a felhasználótol adatokat.
# Beolvassuk a nevét a felhsználonak.
read -p "Mi a neved? " user
echo Szia $user
