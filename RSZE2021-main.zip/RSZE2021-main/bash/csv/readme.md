# AWK alapok p�lda

```shell
sudo apt install unaccent
```
```shell
mkdir ~/elek mkdir ~/mari mkdir ~/akos
```
```shell
cat adat.csv | unaccent utf-8 |awk -F, '{print tolower("mkdir ~/"$2)}'
```
```shell
echo ${szoveg,,}  # kisbet�
```
```shell
echo ${szoveg^^}  # nagybet�
```
```shell
cat adat.csv | unaccent utf-8 |awk -F, '{print tolower(substr($2,1,3))}'
```
```shell
cat adat.csv | unaccent utf-8 |awk -F, '{print tolower(substr($1,1,3)) tolower(substr($2,1,3)) int(9*rand())}'�
```
```shell
cat adat.csv | unaccent utf-8 | awk -F, '{passwd=alma;
system("htpasswd -b ~/database.pass " tolower(substr($1,1,3)) tolower(substr($2,1,3)) " passwd"); print passwd }'
```
