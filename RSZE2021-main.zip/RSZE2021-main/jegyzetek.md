RnS 1-2, Ubuntu server telepites raid 6 lvm, kozgaz:

https://drive.google.com/drive/folders/1Coyhu9_9z4ORNDh4_d9Nh2AyzXr-8yc4?usp=sharing

mooo link = win serveres videok, ubuntu server telepitese(nincs hang):

https://o1.mooo.com:8213/index.php/s/xj2xsXXKfL9tiWW
## Hálózati cím beállitása:
```bash
# sudo ip addr add <ip>/<prefix> dev <interface> 
```
