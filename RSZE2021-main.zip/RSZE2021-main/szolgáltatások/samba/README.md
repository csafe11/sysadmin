# Samba
![samba banner](images/banner.png)

A ***samba*** a Linux és Windows rendszerek közötti fájl és nyomtató megosztára alkalmas szerver szolgáltatás.
A Samba egy ***programgyűjtemény***, mely megvalósítja a ***Server Message Block*** (röviden: SMB) protokollt UNIX rendszereken.
Erre a protokollra hivatkoznak néha ***Common Internet File System*** (CIFS) néven is.
A samba az ***nmbd*** részében a ***NetBIOS*** protokollt is kezeli.
A samba az ***smbd*** részében a ***SMB / CIFS*** protokollt is kezeli.
A samba a ***UNIX*** és ***Linux*** gépeken levő fájl- és nyomtató erőforrásokat tesz elérhetővé ***Windows*** operációs rendszert használó számítógépek részére.
Lehetőséget teremt a fordított elérésre is: Windows megosztásokat használhatunk általa UNIX rendszerekből.

A samba a következő szolgáltatásokat üzemeltetésére alkalmas:
- Fájl- és nyomtatási szolgáltatások
- Hitelesítések és engedélyek kezelése
- Névfeloldás
- Tallózás

Szerverként a következő működhet:
- Önálló szerver (Role Standalone): ebben az esetben a jogosultságokat is a szerver kezeli
- Domain member server: ebben az esetben a jogosultságokat a tartomány vezérlő kezeli
- Primary Domain controller (PDC): Elsődleges tartományvezérlő, ekkor a tartomány teljes körű kiszolgálója (azonosítás, profilok, névszolgáltatás)
- Backup Domain controller (BDC): Csak Samba-s PDC mellett

A windowsos szerverekhez képest (azonos hardveren) teljesítménye általában kisebb, azonban a terhelés növekedésével a különbség csökken. Sok kis fájl olvasása esetén a teljesítménykülönbség "fájdalmas" lehet. Sok esetben jelenthet frappáns megoldást különböző méretű cégeknek.

> A feladatokban mindden esetben az egyszerüség kedvért a serverem IP címét használom a 192.168.56.99. A te servered mási ip cimmel rendelkezik valószinüleg. Az ip címedet a ip a utasitással tudod lekérdezni.

## Samba telepítése
```bash
test@server:~$ sudo apt install samba
```
A telepítés alatt a samba létrehozza a ***sambashare*** csoportot.
A konfigurációs állomány a ***/etc/samba/smb.conf*** állományban található.
A samba a telepítést követően ***ROLE_STANDALONE*** módban indul el.
A samba a ***naplozás***sal kapcsolatos állományokat a ***/var/log/samba/*** könyvtárban tárolja.

### Konfigurációs állomány

A konfigurációs állomány két egymástól jól elkülöníthető részből épül fel:
- globális konfiguráció, ez az a rész ami a szerverünk működését írja le. ***[global]***
- megosztások.

Példa a konfigurációs állományra (smb.conf):
```
[global]
        log file = /var/log/samba/log.%m
        logging = file
        map to guest = Bad User
        max log size = 1000
        obey pam restrictions = Yes
        pam password change = Yes
        panic action = /usr/share/samba/panic-action %d
        passwd chat = *Enter\snew\s*\spassword:* %n\n *Retype\snew\s*\spassword:* %n\n *password\supdated\ssuccessfully* .
        passwd program = /usr/bin/passwd %u
        server role = standalone server
        server string = %h server (Samba, Ubuntu)
        unix password sync = Yes
        usershare allow guests = Yes
        idmap config * : backend = tdb
```
Fontos megjegyezni, hogy mint a legtöbb linuxos konfigurációs állomány az ***smb.conf*** állomány is nagyon sok ***példa kód***ot, ***magyarázat***ot tartalmaz ezek a sorok ***;*** és ***#*** kezdődnek. 
Abban az esetben ha bövebb információra vagy kíváncsi a smb.conf állománnyal kapcsolatban:
```bash
test@server:~$ man smb.conf
```
### Fájl kiszolgálás megvalósitása
Ebben a részben a ***SMB / CIFS*** solgáltatásokat fogjuk konfigurálni a szerveren.
#### Feladat I
Ebben a feladatban szeretnék létrehozni egy megosztást a hálózaton ***adatok*** néven. A megosztáshoz szeretnénk hozzáfűzni a következő magyarázó üzenetet: "***Nyilvános adatok bárki hozzáférhet.***". A megosztás található adatokat a szerveren a ***/srv/samba/adatok*** könyvtárban tároljuk. A megosztást tartalmát ***bárki*** megtekintheti, módosíthatja, bővítheti.
##### Megvalósitás
1 Hozzuk létre a szerveren a /srv/samba/adatok könyvtárat.
```bash
test@server:~$ sudo mkdir -p /srv/samba/adatok
```
2 Állítsuk be a könyvtár tulajdonosát ***nobody***ra. Állítsuk be a könyvtár csoportját a ***nogroup***ra.
```bash
test@server:~$ sudo chown nobody:nogroup /srv/samba/adatok
```
3 Módosítsuk a kiszolgáló konfigurációs állományát. Fűzzük hozzá a fájl végéhez a megosztás beállításához szükséges kód blokkot.

file: /etc/smb.conf:
```
[adatok]
        comment = "Nyilvános adatok bárki hozzáférhet."
        path = /srv/samba/adatok
        guest ok = Yes
        read only = No
```
4 Fontos, hogy az esetleges hibák elkerülése érdekében ellenőrizzük a konfigurációs állomány hiba mentességét.
```bash
test@server:~$ sudo testparm
```
A parancs kimenete:
```
Load smb config files from /etc/samba/smb.conf
Loaded services file OK.
Server role: ROLE_STANDALONE

Press enter to see a dump of your service definitions

# Global parameters
[global]
        log file = /var/log/samba/log.%m
        logging = file
        map to guest = Bad User
        max log size = 1000
        obey pam restrictions = Yes
        pam password change = Yes
        panic action = /usr/share/samba/panic-action %d
        passwd chat = *Enter\snew\s*\spassword:* %n\n *Retype\snew\s*\spassword:* %n\n *password\supdated\ssuccessfully* .
        passwd program = /usr/bin/passwd %u
        server role = standalone server
        server string = %h server (Samba, Ubuntu)
        unix password sync = Yes
        usershare allow guests = Yes
        idmap config * : backend = tdb


[adatok]
        comment = "Nyilvános adatok bárki hozzáférhet."
        path = /srv/samba/adatok
        guest ok = Yes
        read only = No
```
Ha hibát találtunk javítsuk a hibát.

5 Beállítások életbe léptetése, szolgáltatás újraindítása:
```bash
test@server:~$ sudo systemctl restart smbd
```
5+1:
Ellenürizzzük vissza hogy a stolgáltatás rendesen fut a módositások után.
```bash
test@server:~$ sudo systemctl status smbd
```
Ha esetleg hibát tapasztalunk akkor a napló állományokat a /var/log/samba/ könyvtárban találjuk.
Másik alternatíva:
```bash
test@server:~$ sudo journalctl -u smbd.service
```

#### Feladat II
Ebben a feladatban szeretnék létrehozni egy felhasználót akit a samba kezel.

A felhasználó neve: ***test***

A felhasználó jelszava: ***titok***

##### Megvalósítás
Hozzuk létre a samba felhasználót:
```bash
test@server:~$ sudo adduser --no-create-hom --shell /usr/sbin/nologin test
test@server:~$ sudo smbpasswd -a test
```
A parancs kimenete:
```
New SMB password:
Retype new SMB password:
Added user test.
```
Fontos tudni, mint minden linuxos jelszóbeviteli mező esetén ebben az esetben sem jelennek meg a begépelt jelszavak. 

A jelszó bevitelét ENTER segítségével lehet megerősíteni.


#### Feladat III
Ebben a feladatban szeretnénk megváltoztatni egy samba felhasználó jelszavát.

Fontos tudnod, hogy a jelszó a rendszer keretei között vissza állítani nem tudod, ahogy meg nézni sem. 
Üzemeltetőként lehetőséged van bármelyik felhasználó jelszavát megváltoztatni.
A rendszer a begépelt jelszóból minden esetben hash-t állít elő és ezt a hash tárolja. Egy jelszóhoz mindig egy jelszó tartozik viszont a hash birtokában nem lehet kitalálni a jelszavakat.

A felhasználó akinek a jelszavát szeretnénk meváltoztatni: ***test***
A felhasználó új jelszava: ***almafa2920@12***

##### Megvalósítás
Hozzuk létre a samba felhasználót:
```bash
test@server:~$ sudo smbpasswd -U test
```
A parancs kimenete:
```
New SMB password:
Retype new SMB password:
```
Fontos tudni, mint minden linuxos jelszóbeviteli mező esetén ebben az esetben sem jelennek meg a begépelt jelszavak. 

A jelszó bevitelét ENTER segítségével lehet megerősíteni.

#### Feladat IV
Ebben a feladatban szeretnénk letiltani egy samba felhasználó hozzáférését.

Fontos tudnod, hogy 
- ebben az esetben a felhasználó jelszava nem változik meg csak nem tud hozzáférni a megosztásokhoz.
- a letiltás lehet valamilyen védelmi mechanizmus automatikus eredménye is. (többszöri hibás jelszó megadása.)
- Bizonyos vállalati szabályrendszerek esetén, a munkatárs távozása esetén is a letiltást szokták alkalmazni.

A felhasználó akit le szeretnék tiltani: ***test***

##### Megvalósítás
Tiltsuk le a test felhasználót
```bash
test@server:~$ sudo smbpasswd -d test
```
A parancs kimenete:
```
Disabled user test.
```

#### Feladat V
Ebben a feladatban szeretnénk engedélyezni egy letiltott samba felhasználót.

Fontos tudnod, hogy 
- ebben az esetben a felhasználó jelszava nem változik meg csak nem tud hozzáférni a megosztásokhoz.
- a letiltás lehet valamilyen védelmi mechanizmus automatikus eredménye is. (többszöri hibás jelszó megadása.)
- Bizonyos vállalati szabályrendszerek esetén, a munkatárs távozása esetén is a letiltást szokták alkalmazni.

A felhasználó akit engedélyezni szeretnénk: ***test***

##### Megvalósítás
Engedélyezzük test felhasználót
```bash
test@server:~$ sudo smbpasswd -e test
```
A parancs kimenete:
```
Enabled user test.
```

#### Feladat VI
Ebben a feladatban a felhasználót kötelező jelszóváltoztatásra szeretnénk kényzeriteni a következő bejelentkezés alkalmaával.

A felhasználó akit jelszó váltöztatásra kötelezünk: ***test***

##### Megvalósítás
Kötelező jelszó változtatás next login.
```bash
test@server:~$ sudo pdbedit -u test --pwd-must-change-time 0
```
A parancs kimenete:
```
test:1000:Teszt Elek
```
#### Feladat VII
Ebben a feladatban szeretnék létrehozni egy megosztást a hálózaton ***Csoport megosztás*** néven, amihez csak a ***csoport*** nevű csoport tagjai férnek hozzá.

A megosztáshoz szeretnénk hozzáfűzni a következő magyarázó üzenetet: "***Megtekintés csak csoport tagoknak***".

A megosztás található adatokat a szerveren a ***/srv/samba/csoport*** könyvtárban tároljuk.

A megosztást tartalmát csak ***csoport*** tagjai tekintheti meg, módosíthatja, bővítheti.
A csoport nevü csoport tagja legyen a test felhasználó.

##### Megvalósitás
1 Hozzuk létre a ***csoport*** nevű csoportot a szerveren.
```bash
test@server:~$ sudo groupadd csoport
```
2 Mivel a csoport tagságot fájlrendszer szinten is használni szeretnénk hozzunk létre speciális felhasználókat a szerveren.
A Felhasználok a következő korlátozásokkal jönnek létre:
- Nem hozunk létre a felhasználónak saját könyvtárat a szerveren. (--no-create-hom)
- Nem jelentkezhet be a szerverre a felhasználó. (--shell /usr/sbin/nologin)

```bash
test@server:~$ sudo adduser --no-create-hom --shell /usr/sbin/nologin test
```
A parancs kimenete: (A parancs interaktív módon fogja bekérni az adatokat.)
(Ha létezik a test user a rendszeren ez a lépés kihagyható!!!)
```
Adding user `test' ...
Adding new group `test' (1001) ...
Adding new user `test' (1001) with group `test' ...
Not creating home directory `/home/test'.
New password: 
Retype new password: 
No password supplied
New password: 
Retype new password: 
No password supplied
New password: 
Retype new password: 
passwd: password updated successfully
Changing the user information for test
Enter the new value, or press ENTER for the default
        Full Name []: 
        Room Number []: 
        Work Phone []: 
        Home Phone []: 
        Other []: 
Is the information correct? [Y/n] 

```
3 Létre kell hozni a samba rendszerében is a felhasználót:
```bash
test@server:~$ sudo smbpasswd -a test
```
4 Adjuk hozzá a test felhasználót a csoport nevű csoporthoz.
```bash
test@server:~$ sudo adduser test csoport
```
A parancs kimenete:
```
Adding user `test' to group `csoport' ...
Adding user test to group csoport
Done.
```
5 A adatok tárolására a könyvtár létrehozása a szerveren.
```bash
test@server:~$ sudo mkdir /srv/samba/csoport
```
6 A szerveren lévő könyvtár tulajdonosának és csoportjának bestialitása: (A tulajdonos a root felhasználó lesz, a csoport pedig a csoport.)
```bash
test@server:~$ sudo chown root:csoport /srv/samba/csoport
```
7 A szerveren a tárolókönyvtár jogosultságaink beállítása:
```bash
test@server:~$ sudo chmod 2775 /srv/samba/csoport
```
8 Biztonsági másolat készítése a jelenlegi konfigurációs állományról:
```bash
test@server:~$ sudo cp /etc/samba/smb.conf /etc/samba/smb.conf.origin
```
9 A konfigurációs fájl végéhez írjuk hozzá a következő megosztási definíciót:
```
[Csoport megosztás]

     path = /srv/samba/csoport
     browseable = yes
     guest only = no
     read list = @csoport
     write list = @csoport
     force create mode = 0665
     force directory mode = 2775
     comment = "Megtekintés csak csoport tagoknak"
```
10 Ellenőrizzük a konfigurációs állományt az esetleges hibák kijavítása érdekében:
```bash
test@server:~$ sudo testparm
```
11 Indítsuk újra az smbd szolgáltatást:
```bash
test@server:~$ sudo systemctl restart smbd
```

# Samba megosztás vagy Windows fájl megosztás elérése Linuxon

Ezt a feladatott több féle módon is meg lehet oldani most csak 2 megoldást mutatok be.

## Elérés I
Ez talán a leg egyszerűbb megoldás de nem a legkényelmesebb,

Tesztelésre javaslom.

Samba kliens telepítése:
```bash
test@server:~$ sudo apt install smbclient
```
#### Feladat VIII
Ebben a feladatban szeretnék kilistázni a 192.168.56.99 IP címen található szerver megosztásait. 

##### Megvalósitás
```bash
smbclient -L 192.168.56.99
```
A parancs kimenete:
```
Enter WORKGROUP\test's password: 
Anonymous login successful

        Sharename       Type      Comment
        ---------       ----      -------
        public          Disk      nyilvános megosztás
        private         Disk      privat megosztás
        IPC$            IPC       IPC Service (server server (Samba, Ubuntu))
SMB1 disabled -- no workgroup available
```
#### Feladat IX
Ebben a feladatban szeretnék kilistázni a ***192.168.56.99*** IP címen található szerver megosztásait a ***test*** user-t használva. 

##### Megvalósitás I
```bash
test@server:~$ smbclient -L 192.168.56.99 -U test
```
##### Megvalósitás II
Lehetőségünk van a kiadott parancsban megadni a felhasználó nevet és a jelszót is. Biztonságosnak nem nevezhető megoldás, de néha hasznos.

A példában a ***test*** felhasználó jelszava ***passwors***
```bash
test@server:~$ smbclient -L 192.168.56.99 -U test%passwors
```
#### Feladat X
Ebben a feladatban szeretnék kilistázni a ***192.168.56.99*** IP címen található ***public*** megosztásának tartalmát megtekinteni.

##### Megvalósitás
1 lépés kapcsolodás a kiszolgálóhoz:
```bash
test@server:~$ smbclient  //192.168.56.99/adatok
```
A parancs kimenete:
```
Enter WORKGROUP\test's password: 
Anonymous login successful
Try "help" to get a list of possible commands.
smb: \>
```
2 A megosztás tartalmának megtekintése:
```
smb: \> dir
```
A parancs kimenete:
```
  .                                   D        0  Fri Nov 20 08:55:02 2020
  ..                                  D        0  Fri Nov 20 08:14:35 2020
  README.md                           A     1484  Fri Nov 20 08:55:02 2020

                9219412 blocks of size 1024. 4493492 blocks available
```
#### Feladat XI
Ebben a feladatban szeretnék feltölteni az aktuális könyvráunkban található alma.txt állományt feltölteni a ***192.168.56.99*** IP címen található ***public*** megosztásba.

##### Megvalósitás
1 lépés kapcsolodás a kiszolgálóhoz:
```bash
test@server:~$ smbclient  //192.168.56.99/adatok
```
2 A fájl feltöltése:
```
smb: \> put alma.txt
```
A parancs kimenete:
```
putting file alma.txt as \alma.txt (18.0 kb/s) (average 18.0 kb/s)
```
#### Feladat XII
Ebben a feladatban szeretnék letölteni az aktuális könyvráunkban a szerveren találhtó ***körte.txt*** állományt a ***192.168.56.99*** IP címen található ***public*** megosztásból.

##### Megvalósitás
1 lépés kapcsolodás a kiszolgálóhoz:
```bash
test@server:~$ smbclient  //192.168.56.99/adatok
```
2 A file letöltése:
```
smb: \> get körte.txt
```
A parancs kimenete:
```
getting file \körte.txt of size 92 as körte.txt (89.8 KiloBytes/sec) (average 89.8 KiloBytes/sec)
```

## Elérés II
A másik elérési mód esetén a CIFS lehetőségeit fogjuk kihasználni úgy, hogy a megosztást a Linux fájlrendszerébe csatoljuk.
A CISFS használatához telepiteni kell a ***cifs-utils*** csomagot.
Csomag teleítése:
```bash
test@server:~$ sudo apt install cifs-utils
```
#### Feladat XIII
Ebben a feladatban szeretnék a ***192.168.56.99*** ip címen található server ***public*** megosztását a saját számítógépünkön a ***/mnt/publik*** könyvtárában elérni.

##### Megvalósitás
1 Lépés hozzuk létre a könyvtárat a saját gépünkön a /mnt/publik könyvtárat.
```bash
test@server:~$ sudo mkdir -p /mnt/publik
```
2 A könvtár csoportjának és tulajdonosának beállitása:
```bash
test@server:~$ sudo chown test:root /mnt/publik
```
3 A hálózati megosztás csatolása:
```bash
test@server:~$ sudo mount -t cifs //192.168.56.99/adatok /mnt/publik
```
Ezek után a /mnt/publik könyvtárban úgy tudjuk használni a megosztás mintha az a helyi számítógépünk  egy könyvtára lenne.

Fontos megjegyezni hogy ez a csatolás csak addig marad érvényben ameddig a számítógépünk ki nem kapcsol. (Nem tartós.)

#### Feladat XIV
Ebben a feladatban szeretnék a ***192.168.56.99*** ip címen található szerver ***public*** megosztását a saját számítógépünkön a ***/mnt/tartos*** könyvtárában elérni. Úgy, hogy az tartós legyen (A számítógép újraindítása után is legyen elérhető)

##### Megvalósitás
1 Lépés hozzuk létre a könyvtárat a saját gépünkön a /mnt/publik könyvtárat.
```bash
test@server:~$ sudo mkdir -p /mnt/tartos
```
2 A könvtár csoportjának és tulajdonosának beállitása:
```bash
test@server:~$ sudo chown test:root /mnt/tartos
```
3 Szerkeszük a /etc/fstab állományt. Adjuk hozzá a követező sort a fájl végéhez:
```
//192.168.56.99/adatok  /mnt/tartos  cifs  guest,uid=1000,iocharset=utf8  0  0
```
Mentsük el a /etc/fstab fájt.
4 A csatolás még nem történt meg. Adjuk ki a következő parancsot:
```bash
test@server:~$ sudo mount -a
```
## Samba megosztás elérése Windows alól
#### Feladat XV
Ahhoz hogy a feladatok el tudd végezni fontos hogy a Linux server és a Windows között a hálózati kapcsolat megfelelő legyen.

A feladat a kapcsolat ellenörzése.

##### Megvalósitás I
A cmd használatával a window 10-ről adjuk ki a következő utasitást:
```
ping 192.168.56.99
```
##### Megvalósitás II
A powershell használatával a windows 10-ről adjuk ki a következő utasitást:
```powershell
 Test-Connection -ComputerName 192.168.56.99
```
#### Feladat XVI
Ebben a feladatban szeretnék a ***192.168.56.99*** ip címen található szerver ***public*** megosztását a megnyitni a Windows Intéző segítségével.

##### Megvalósitás
1 Nyissuk meg a windows Intészőt és irjuk be a cimsórba a következőt:
```
\\192.168.56.99\adatok
```
![intezo url](images/Intezo1.jpg)
Nyomjunk entert.
![intezo tartalom](images/Intezo2.jpg)

#### Feladat XVII
Ebben a feladatban szeretnék a ***192.168.56.99*** ip címen található szerver ***public*** megosztását a szeretnénk csatolni z: meghajtóként.

##### Megvalósitás
1 Nyomjuk meg a Windows + r billentyü kombinációt.
2 A futattás Megnyitás mezőbe gépeljök be a következő utasitást:
```
rundll32.exe Shell32.dll,SHHelpShortcuts_RunDLL Connect
```
![futatás net csat](images/Intezo3.jpg)

3 Nyomjuk meg az ok gombot.

4 A hálózati meghajtó csatolása ablakban tölzsd ki az adatokat a képen látható módon.
![net csat](images/Intezo4.jpg)

#### Feladat XVIII
Ebben a feladatban szeretnék a ***192.168.56.99*** ip címen található szerver ***public*** megosztását a szeretnénk csatolni x: meghajtóként a cmd haszálva.

##### Megvalósitás
1 Nyomjuk meg a Windows + r billentyü kombinációt.
2 A futattás Megnyitás mezőbe gépeljök be a következő utasitást:
```
cmd
```
3 A megjelenő terminálba gépeljük be a következő utasitást:
```
net use x: \\192.168.56.99\adatok
```
Megjelgytés ha le szeretnén választani a megosztást ahsználd a következő parancsot:
```
net use x: /delete
```
#### Feladat XIX
Ebben a feladatban szeretnék a ***192.168.56.99*** ip címen található szerver ***public*** megosztását a szeretnénk csatolni y: meghajtóként a Powershell-t haszálva.

##### Megvalósitás
1 Nyomjuk meg a Windows + r billentyü kombinációt.

2 A futattás Megnyitás mezőbe gépeljök be a következő utasitást:
```
powershell
```
3 A powershell-be add ki a következő utasitást:
```powershell
New-PSDrive –Name “y” –PSProvider FileSystem –Root “\\192.168.56.99\adatok” –Persist
```

# Samba mint Tartomány vezérlő

A modern samba képes Windows tartomány vetélőként működni.

A különböző samba verziók különböző AD működési szinteket képesek megvalósítani:
Müködösi szint | Samba Verzió
---------------|---------------------------
2012_R2        |	4.4 and later*
2012           |	4.4 and later*
2008_R2	       |    4.0 and later
2008           |	4.0 and later
2003           |	4.0 and later

A samba müködéséhez mit tartomány vezérlő elengethetetlenül szükséges elvégezni a következő beállitásokat:
- Jól kell járnia a rendszer órának.
- A szervernek kell rendelkeznie jól beállitott host névvel.
- A szervernek rendelkeznie kell domain névvel
- A szervernek rendelkezni kell FQDN-nnel.
- Mivel az AD-ban DNS szolgáltatást szeretnék nyújtani, fix ip címmel kell rendelkeznünk. 

Az ubuntu ki kell kapcsolni a ***systemd-resolved.service*** szolgáltatást mivel ez kezeli az dns szolgáltatás és azt a sambával szeretnénk majd kezelni.

A ***systemd-resolved.service*** kikapcsolásának következményei:
- Nem lesz névfeloldás a szerveren. (meg kell oldani.)
- Nem lesz dns keresési tartomány.

# Samba tartoményvezérló mentés
# Samba Virusellenörzés
# Samba sebezhetőségek CVE
# Samba docker kontinerben
:)
