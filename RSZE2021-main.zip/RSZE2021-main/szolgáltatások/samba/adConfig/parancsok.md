Csoportok add gid:
```bash
ldbmodify -H ldap://localhost -b CN=Users,DC=test,DC=lan -U administrator --password=Nincs123456 -v -i < groups.ldif
```
