# Samba Active Directory

A samba active direktori beüzemeléséhez szükséges egy telepitett samba a a linux rendszeren.

A szervernek meg kell felelnie a következő feltételeknek:
- **Pontosan kell járnia a rendszerórának**.
- **Fix ip címmel kell rendelkelznie.**
- A szerveren be kell állitani a 
    - ***hostnevet***
    - ***domani nevet***
    - ***be kell állitani az fqdn (Fully Qualified Domain Name - teljesen minősített tartománynév) (PL: server.test.lan)***

## Server előkészítése:
A 
### Idő beállitása
Ebben a részben két megoldát néuuünk meg, ***ntpd*** haználata (régi megoldás) és a ***systemd-timesyncd*** használatának segytségével.
#### ntpd
A rendszeridő pontosantartásához szükséges szolgáltatás telepítése:

```bash
test@server$ sudo apt install npt
```
Konfigurácios állományt a ***/etc/ntp.conf*** álllományban van.

A lényeges beállitások az idő szerverek:
```
# Use servers from the NTP Pool Project. Approved by Ubuntu Technical Board
# on 2011-02-08 (LP: #104525). See http://www.pool.ntp.org/join.html for
# more information.
pool 0.ubuntu.pool.ntp.org iburst
pool 1.ubuntu.pool.ntp.org iburst
pool 2.ubuntu.pool.ntp.org iburst
pool 3.ubuntu.pool.ntp.org iburst

# Use Ubuntu's ntp server as a fallback.
pool ntp.ubuntu.com
```
A szolgáltatás informáciokat a 
```bash
sudo systemctl status ntp
```
Az ntp eltávolitása:
```bash
apt remove ntp  
```
#### systemd-timesyncd
Az ubuntu 20.04 server esetén az alapértelmezett a systemd ez a rendszer alapértelmezetten tartalmazza a rendszeridő szinkronizálását.

A beállitásokat a ***/etc/systemd/timesyncd.conf*** fájban tárolja a rendszer.
```
[Time]
#NTP=
#FallbackNTP=0.arch.pool.ntp.org 1.arch.pool.ntp.org 2.arch.pool.ntp.org 3.arch.pool.ntp.org
#RootDistanceMaxSec=5
#PollIntervalMinSec=32
#PollIntervalMaxSec=2048
```
NTP szolgáltatás elindotása/állapot lekérdezése:
```bash
sudo systemctl status systemd-timesyncd  # lekérdezés
sudo systemctl start systemd-timesyncd   # start
sudo systemctl enable systemd-timesyncd  # a következő inditáskor automatikusan elinditja.
```

A szolgáltatás automatikus inditása, inditása a ***timedatectl set-ntp true*** segítségével lehet.
```bash
sudo timedatectl set-ntp true
```
A szolgáltatásokrol információt a ***timedatectl status*** parancs segítsgével lehetséges.
```bash
sudo timedatectl status
```
A beállitásokat a ***timedatectl show-timesync --all*** parancs segítségével lehet ellenörizni.
``` bash
sudo timedatectl show-timesync --all
```
A parancs kimenete:
```
LinkNTPServers=
SystemNTPServers=
FallbackNTPServers=ntp.ubuntu.com
ServerName=ntp.ubuntu.com
ServerAddress=91.189.89.199
RootDistanceMaxUSec=5s
PollIntervalMinUSec=32s
PollIntervalMaxUSec=34min 8s
PollIntervalUSec=8min 32s
NTPMessage={ Leap=0, Version=4, Mode=4, Stratum=2, Precision=-23, RootDelay=9.017ms, RootDispersion=27.725ms, Reference=250FDDBD, OriginateTimestamp=Thu 2020-11-26 07:25:34 UTC, ReceiveTimestamp=Thu 2020-11-26 07:25:34 UTC, TransmitTimestamp=Thu 2020-11-26 07:25:34 UTC, DestinationTimestamp=Thu 2020-11-26 07:25:34 UTC, Ignored=no PacketCount=4, Jitter=5.783ms }
Frequency=1522277
```
A rendszeridő pontosságának ellenörzése a ***timedatectl timesync-status*** parancs segítségével lehetséges.
```bash
sudo timedatectl timesync-status
```
A parancs kimenete:
```
       Server: 91.189.89.199 (ntp.ubuntu.com)   
Poll interval: 17min 4s (min: 32s; max 34min 8s)
         Leap: normal                           
      Version: 4                                
      Stratum: 2                                
    Reference: 11FD227B                         
    Precision: 1us (-23)                        
Root distance: 23.589ms (max: 5s)               
       Offset: -10.141ms                        
        Delay: 35.084ms                         
       Jitter: 5.375ms                          
 Packet count: 5                                
    Frequency: +18.276ppm 
```
Ubuntu rendszerek alatt a rendszeridőbeálitását a 
Timezonák lsitája:
```bash
timedatectl list-timezone
```
Timezona beállitása:

Rendszeridó beállitása:

```bash
timedatectl set-time 15:58:30
```

```bash
sudo timedatectl set-timezone "Europe/Budapest"
```


#### Fix ip cim beállitása
##### Netplan
A konfigurácios álomny ***/etc/netplan/fixip.yaml***.
A ***/etc/netplan/fixip.yaml***: (fix ip)
```
network:
   version: 2
   renderer: networkd
   ethernets:
      enp0s8:
         addresses:
            - 192.168.56.99/24
         # gateway4: 10.100.1.1
```
Példa: dhcp (Most nem használjuk)
```
network:
    version: 2
    renderer: networkd
    ethernets:
        enp3s0:
            dhcp4: true
```
Pálda fix ip keresési tartomány multi addres: (Most nem használjuk)
```
network:
    version: 2
    renderer: networkd
    ethernets:
        enp3s0:
            addresses:
                - 10.10.10.2/24
            gateway4: 10.10.10.1
            nameservers:
                search: [mydomain, otherdomain]
                addresses: [10.10.10.1, 1.1.1.1]
```
Connecting multiple interfaces with DHCP (Most nem használjuk)
```
network:
    version: 2
    ethernets:
        enred:
            dhcp4: yes
            dhcp4-overrides:
                route-metric: 100
        engreen:
            dhcp4: yes
            dhcp4-overrides:
                route-metric: 200

```
wireless nyilt hálózat (Most nem használjuk)
```
network:
    version: 2
    wifis:
        wl0:
            access-points:
                opennetwork: {}
            dhcp4: yes
```
wifi wpa: (Most nem használjuk)
```
network:
    version: 2
    renderer: networkd
    wifis:
        wlp2s0b1:
            dhcp4: no
            dhcp6: no
            addresses: [192.168.0.21/24]
            gateway4: 192.168.0.1
            nameservers:
                addresses: [192.168.0.1, 8.8.8.8]
            access-points:
                "network_ssid_name":
                    password: "**********"
```
wifi wpa Enterprise TTLS: (Most nem használjuk)

```
network:
    version: 2
    wifis:
        wl0:
            access-points:
                workplace:
                    auth:
                        key-management: eap
                        method: ttls
                        anonymous-identity: "@internal.example.com"
                        identity: "joe@internal.example.com"
                        password: "v3ryS3kr1t"
            dhcp4: yes
```

wifi nagyválalati hitelesitó server wpa-eap: (Most nem használjuk)
```
network:
    version: 2
    wifis:
        wl0:
            access-points:
                university:
                    auth:
                        key-management: eap
                        method: tls
                        anonymous-identity: "@cust.example.com"
                        identity: "cert-joe@cust.example.com"
                        ca-certificate: /etc/ssl/cust-cacrt.pem
                        client-certificate: /etc/ssl/cust-crt.pem
                        client-key: /etc/ssl/cust-key.pem
                        client-key-password: "d3cryptPr1v4t3K3y"
            dhcp4: yes
```
vlan: (Most nem használjuk)
```
network:
    version: 2
    renderer: networkd
    ethernets:
        mainif:
            match:
                macaddress: "de:ad:be:ef:ca:fe"
            set-name: mainif
            addresses: [ "10.3.0.5/23" ]
            gateway4: 10.3.0.1
            nameservers:
                addresses: [ "8.8.8.8", "8.8.4.4" ]
                search: [ example.com ]
    vlans:
        vlan15:
            id: 15
            link: mainif
            addresses: [ "10.3.99.5/24" ]
        vlan10:
            id: 10
            link: mainif
            addresses: [ "10.3.98.5/24" ]
            nameservers:
                addresses: [ "127.0.0.1" ]
                search: [ domain1.example.com, domain2.example.com ]

```
A beállitások alkalmazása:
```bash
netplan apply
```

##### hostnév beállitása
```bash
hostnamectl set-hostname server
```
##### fqdn
```bash
hostnamectl set-hostname server.test.lan
```
Samba ad-dc
-1 lépés:
```bash
sudo rm -f /etc/samba/smb.conf
```
0 
```bash
sudo systemctl stop systemd-resolved
sudo systemctl disable systemd-resolved
sudo unlink /etc/resolv.conf
```
```bash
sudo vim /etc/resolv.conf
```
```
nameserver 8.8.8.8
search test.lan
```
A dc beállitások előkészítése:
```bash
sudo apt install winbind
sudo systemctl mask smbd nmbd winbind
sudo systemctl disable smbd nmbd winbind
sudo systemctl stop smbd nmbd winbind
sudo systemctl unmask samba-ad-dc
sudo systemctl enable samba-ad-dc
sudo reboot
```

```bash
sudo samba-tool domain provision --use-rfc2307 --interactive
```
A samba ad törlése ha szükséges
```bash
sudo apt -y remove --purge samba samba-common cifs-utils smbclient
```
```bash
sudo rm -rf /var/cache/samba /etc/samba /run/samba /var/lib/samba /var/log/samba
```
```bash
apt install samba winbind
```
```bash
sudo rm /etc/samba/smb.conf
```
```bash
sudo samba-tool domain provision --use-rfc2307 --interactive
```
Az Administrator jelszó 8 karakter hosszú, kel bele kisbetü nagybetü és szám is.
```bash
sudo systemctl unmask samba-ad-dc
```
```bash
sudo systemctl enable samba-ad-dc
```
```bash
sudo reboot
```
```bash
apt install winbind
```
```bash
systemctl start samba-ad-dc
```
# Powershell rsat install
```powershell
Get-WindowsCapability -Name RSAT* -Online | Add-WindowsCapability -Online
```
